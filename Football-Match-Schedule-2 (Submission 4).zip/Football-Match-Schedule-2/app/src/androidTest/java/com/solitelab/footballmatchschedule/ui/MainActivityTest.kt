package com.solitelab.footballmatchschedule.ui

import android.support.test.InstrumentationRegistry
import android.support.test.espresso.Espresso.*
import android.support.test.espresso.action.ViewActions.click
import android.support.test.espresso.assertion.ViewAssertions.matches
import android.support.test.espresso.contrib.RecyclerViewActions
import android.support.test.espresso.matcher.ViewMatchers.*
import android.support.test.rule.ActivityTestRule
import android.support.test.runner.AndroidJUnit4
import android.support.v7.widget.RecyclerView
import com.solitelab.footballmatchschedule.R.id.*
import com.solitelab.footballmatchschedule.Util
import com.solitelab.footballmatchschedule.Util.withIndex
import org.hamcrest.Matchers
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class MainActivityTest {
    @Rule
    @JvmField var activityRule = ActivityTestRule(MainActivity::class.java)

    @Test
    fun testRecyclerViewBehaviour() {
        //cek apakah league_list ditampilkan di layar
        onView(withId(league_list))
            .check(matches(isDisplayed()))

        //lakukan aksi scroll ke posisi item ke-7
        onView(withId(league_list)).perform(RecyclerViewActions.scrollToPosition<RecyclerView.ViewHolder>(7))

        //lakukan aksi click pada item ke-7
        onView(withId(league_list)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(7, click()))
    }

    @Test
    fun lastMatchFavoriteTest() {
        //klik view pada posisi 0
        onView(withId(league_list)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))

        //tunggu sampai loading selesai, kurang lebih 10 detik
        Thread.sleep(10000)

        //cek apakah view dengan id match_list yg ke index-0 tampil di layar
        onView(withIndex(withId(match_list), 0))
            .check(matches(isDisplayed()))

        //klik view yg teksnya sama dengan 22:30:00
        onView(withIndex(withText("Leicester"), 0)).perform(click())

        //cek apakah tombol favorit ditampilkan di layar
        onView(withId(favorite))
            .check(matches(isDisplayed()))

        //lakukan aksi klik pada tombol favorit
        onView(withId(favorite)).perform(click())

        //pencet back (Kembali ke MatchActivity)
        pressBack()

        //delay 1 detik
        Thread.sleep(1000)

        //pencet back (Kembali ke MainActivity)
        pressBack()

        //delay 1 detik
        Thread.sleep(1000)

        //buka menu action bar
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getContext())

        //delay 1 detik
        Thread.sleep(1000)

        //pencet menu Favorite Match
        onView(withText("Favorite Match")).perform(click())

        //delay 1 detik
        Thread.sleep(1000)

        //cek view yang memiliki teks tersebut ditampilkan
        onView(withIndex(withId(match_list), 0)).check(
            matches(
                Util.hasItemm(
                    hasDescendant(
                        withText(
                            Matchers.containsString("Leicester")
                        )
                    )
                )
            )
        )
    }

    @Test
    fun nextMatchFavoriteTest() {
        //klik view pada posisi 0
        onView(withId(league_list)).perform(
            RecyclerViewActions.actionOnItemAtPosition<RecyclerView.ViewHolder>(0, click()))

        //klik tab NEXT MATCH
        onView(withText("NEXT MATCH")).perform(click())

        //tunggu sampai loading selesai, kurang lebih 10 detik
        Thread.sleep(10000)

        //cek apakah view dengan id match_list yg ke index-1 tampil di layar
        onView(withIndex(withId(match_list), 1))
            .check(matches(isDisplayed()))

        //lakukan aksi klik pada view dengan tulisan Liverpool
        onView(withIndex(withText("Liverpool"), 0)).perform(click())

        //delay 1 detik
        Thread.sleep(1000)

        //cek apakah tombol favorite tampil di layar
        onView(withId(favorite))
            .check(matches(isDisplayed()))

        //lakukan aksi klik pada tombol favorite
        onView(withId(favorite)).perform(click())

        //pencet back (Kembali ke MatchActivity)
        pressBack()

        //delay 1 detik
        Thread.sleep(1000)

        //pencet back (Kembali ke MainActivity)
        pressBack()

        //delay 1 detik
        Thread.sleep(1000)

        //buka menu action bar
        openActionBarOverflowOrOptionsMenu(InstrumentationRegistry.getContext())

        //delay 1 detik
        Thread.sleep(1000)

        //pencet menu Favorite Match
        onView(withText("Favorite Match")).perform(click())

        //delay 1 detik
        Thread.sleep(1000)

        //lakukan aksi klik pada tab NEXT MATCH
        onView(withText("NEXT MATCH")).perform(click())

        //cek apakah ada view dengan tulisan Liverpool
        //cek view yang memiliki teks tersebut ditampilkan
        onView(withIndex(withId(match_list), 1)).check(
            matches(
                Util.hasItemm(
                    hasDescendant(
                        withText(
                            Matchers.containsString("Liverpool")
                        )
                    )
                )
            )
        )
    }
}